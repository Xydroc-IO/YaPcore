# YaP Vehicles resource pack

Custom icons for upgrade parts (CustomModelData **77101–77107** on `paper`).

## Install

1. Zip this folder (or use the generated `yap-vehicles.zip` next to it)
2. Drop into `resourcepacks/` and set active in YaPcore / Paper
   OR send to clients via your pack HTTP / `server.properties`

## CustomModelData map

| CMD | Upgrade |
|-----|---------|
| 77101 | turbo_engine |
| 77102 | eco_carburetor |
| 77103 | sport_tires |
| 77104 | reinforced_armor |
| 77105 | fuel_tank_xl |
| 77106 | racing_suspension |
| 77107 | nitro_kit |

Replace PNGs under `assets/yapvehicles/textures/item/` with your art.
Authors registering new upgrades should pick CMD ≥ 77200 and add overrides.


## High-res vehicle models

CustomModelData **77200–77210** on `paper` → full 3D body models
(`assets/yapvehicles/models/vehicle/`). Textures are **64×64**.

| CMD | Model |
|-----|-------|
| 77200 | chassis |
| 77201 | buggy |
| 77202 | truck_4x4 |
| 77203 | monster_truck |
| 77204 | sport_car |
| 77205 | hypercar |
| 77206 | lambo |
| 77207 | ferrari |
| 77208 | mclaren |
| 77209 | porsche |
| 77210 | hoverbike |

Enable in plugin: `visuals.high-res-models: true`
Replace PNGs / JSON to upgrade art quality further.

## Model showcase (demo images)

Preview PNGs for every fleet body live in [`showcase/`](showcase/) — open
[`showcase/README.md`](showcase/README.md) for the gallery table.

Regenerate after art changes:

```bash
python3 scripts/generate-vehicle-showcase.py
```

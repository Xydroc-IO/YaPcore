# YaP Vehicles — model showcase

Demo previews of the **high-res ItemDisplay bodies** shipped in the
`yap-vehicles` resource pack (CustomModelData **77200–77210**).

These PNGs are **marketing / docs previews** — not loaded by Minecraft.
In-game art lives under `assets/yapvehicles/models/vehicle/` and
`assets/yapvehicles/textures/entity/`.

## Gallery

| Preview | Id | In-game name |
|---------|-----|--------------|
| ![YaP Chassis](chassis.png) | `chassis` | YaP Chassis · CMD 77200 |
| ![Buggy](buggy.png) | `buggy` | Buggy · CMD 77201 |
| ![4×4 Truck](truck_4x4.png) | `truck_4x4` | 4×4 Truck · CMD 77202 |
| ![Monster Truck](monster_truck.png) | `monster_truck` | Monster Truck · CMD 77203 |
| ![Sport Car](sport_car.png) | `sport_car` | Sport Car · CMD 77204 |
| ![Hypercar](hypercar.png) | `hypercar` | Hypercar · CMD 77205 |
| ![Lambo SV](lambo.png) | `lambo` | Lambo SV · CMD 77206 |
| ![Ferrari XX](ferrari.png) | `ferrari` | Ferrari XX · CMD 77207 |
| ![McLaren GT](mclaren.png) | `mclaren` | McLaren GT · CMD 77208 |
| ![Porsche Turbo](porsche.png) | `porsche` | Porsche Turbo · CMD 77209 |
| ![Hoverbike](hoverbike.png) | `hoverbike` | Hoverbike · CMD 77210 |

## Regenerate

```bash
python3 scripts/generate-vehicle-showcase.py
```

Requires `python3` + Pillow (`pip install pillow`).

See [VEHICLES.md](../../docs/plugins/VEHICLES.md) for spawn commands and physics.
